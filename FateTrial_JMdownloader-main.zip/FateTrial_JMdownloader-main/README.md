# JMdownloader

使用前请自行使用CMD等方式下载JMcomic依赖库

pip install jmcomic -i https://pypi.org/project -U或pip install git+https://github.com/hect0x7/JMComic-Crawler-Python

pip install img2pdf

也可以通过 管理面板->控制台 右上角的 安装 Pip 库 按钮来安装

若JM域名过期，请前往option.yml自行更换

此版本为1.0.0版本，会持续更新更多功能

注意！插件不会自行删除图片和pdf，使用时间过久可能会占用磁盘，需自行手动删除

如果不会配置cookie，请上网找教程，如果不需要cookie，请手动删除option.yml中的postman下所有配置

# 支持

[帮助文档](https://astrbot.soulter.top/center/docs/%E5%BC%80%E5%8F%91/%E6%8F%92%E4%BB%B6%E5%BC%80%E5%8F%91/
)
